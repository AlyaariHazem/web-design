// function toggle(){
//     var menu=document.getElementById("menu");
//     var cachosencel=document.getElementById("chose");
//     var putton_cancel=document.getElementById("cancell");
//     if(menu.style.display==="none"&&chose.style.display!=="block"||putton_cancel.style.display==="none"){
//         menu.style.display="block";
//         chose.style.display="none";
//         putton_cancel.style.display="block";
//     }
//     else{
//         menu.style.display="none";
//         chose.style.display="block";
//         putton_cancel.style.display="none";
//     }
// }

function open1() {
    document.getElementById("mySidebar").style.display = "block";
  }
  
  function close1() {
    document.getElementById("mySidebar").style.display = "none";
  }