
let a="wat silce english time ";
console.log(a.toUpperCase());
console.log(a.charAt("si"));
console.log(a.endswith('emi'));

